import numpy as np
from scipy.io import wavfile
import matplotlib.pyplot as plt
import subspace
import pyroomacoustics as pra
import tensorflow as tf
from tensorflow.contrib.framework.python.ops import audio_ops as contrib_audio

##Initialising the process
snr_vals = np.arange(50,-25,-5)

noisy_save = np.zeros((len(snr_vals),17118))
for i, snr in enumerate(snr_vals):
    fs_noisy, noisy_signal = wavfile.read('Testing_audio/sources/original_signal_snr_db_{}.wav'.format(snr))
    noisy_signal = np.divide(noisy_signal, 32768)
    noisy_save[i] = noisy_signal

##Subspace

K = 80
T = 10
mu = 10
threshold = 0.1

processed_audio_subsapce = np.zeros((len(snr_vals),17118))

for i, snr in enumerate(snr_vals):
    fs, enhanced_signal = subspace.subspace_enhance('Testing_audio/sources/original_signal_snr_db_{}.wav'.format(snr), K, T, mu, threshold)
    processed_audio_subsapce[i] = np.squeeze(enhanced_signal)


## Spectar substraction
# the reduction criteria of the algorithm in dB
db_reduc = 10
# lookback this main samples for the noise floor estimate
lookback = 10  
# the lenght of our FFT
fft_len = 512
# value of the coefficient used to do the transition between the 2 values we are choosing from in the algorithm
beta = 30
alpha = 6.9
# number of bins we're gonna use for our FFT
n_fft_bins = fft_len//2 + 1 
# array containing our powers that we use in our algorithm (we're gonna take the max value from this array)
P_prev = np.zeros((n_fft_bins, lookback))
# minmal value that our filter can take
Gmin = 10**(-db_reduc/20)
# our filter at the start: an empty array
G = np.zeros(n_fft_bins) 

hop = fft_len//2
window = pra.hann(fft_len, flag='asymmetric', length='full') 
stft = pra.realtime.STFT(fft_len, hop=hop, analysis_window=window, channels=1)

processed_audio_array = np.zeros((len(snr_vals),17118))

for i, snr in enumerate(snr_vals):

    n = 0
    while 17118 - n > hop:
        # go to frequency domain
        stft.analysis(noisy_save[i][n:(n+hop)])
        X = stft.X

        # estimate of signal + noise at current time
        P_sn = np.real(np.conj(X)*X)    

        # estimate of noise level
        P_prev[:,-1] = P_sn
        P_n = np.min(P_prev, axis=1)

        # compute mask
        for k in range(n_fft_bins):
            G[k] = max((max(P_sn[k] - beta*P_n[k],0)/P_sn[k])**alpha, Gmin)

        # back to time domain
        processed_audio_array[i][n:n+hop] = stft.synthesis(G*X)

        # update step
        P_prev = np.roll(P_prev, -1, axis=1)
        n += hop

stft.reset()

## Neural Network Related Functions
# load the graph we're gonna use for labelling
def  load_graph(f):
    with tf.gfile.FastGFile(f,'rb') as graph:
        graph_def = tf.GraphDef()
        graph_def.ParseFromString(graph.read())
        tf.import_graph_def(graph_def, name='')

# load the labels we're gonna use with the graph
def load_labels(f):
    return [line.rstrip() for line in tf.gfile.GFile(f)]

# run the graph and label our file. We add the fact that this function returns the prediction such that we can work with it afterwards.
def run_graph(wav_data, labels, index, how_many_labels=3):
    with tf.Session() as session:
        softmax_tensor = session.graph.get_tensor_by_name("labels_softmax:0")
        predictions, = session.run(softmax_tensor,{"wav_data:0": wav_data})

    top_k = predictions.argsort()[-how_many_labels:][::-1]
    for node_id in top_k:
        human_string = labels[node_id]
        score = predictions[node_id]
        print('%s (score = %.5f)' % (human_string, score))
    return predictions[index]

# main function used for labelling. We add a retrun to this function to recover the results.
# this function labels wavfiles so you always need to create a wavfile of your sound to label it.

def label_wav(wav,labels,graph,word):

    if not wav or not tf.gfile.Exists(wav):
        tf.logging.fatal('Audio file does not exist %s',wav)
    if not labels or not tf.gfile.Exists(labels):
        tf.logging.fatal('Labels file does not exist %s', labels)
    if not graph or not tf.gfile.Exists(graph):
        tf.logging.fatal('Graph file does not exist %s', graph)

    labels_list = load_labels(labels)
    load_graph(graph)

    with open(wav,'rb') as wav_file:
        wav_data = wav_file.read()
    index = labels_list.index(word)
    return run_graph(wav_data,labels_list,index)
    
## Running the scoring
score_original = np.zeros(len(snr_vals))
score_subspace = np.zeros(len(snr_vals))
score_processing = np.zeros(len(snr_vals))

labels_file = "conv_labels.txt"
graph_file = "my_frozen_graph.pb"

for i, snr in enumerate(snr_vals):
    
    print("SNR : %f dB" % snr)
    
    namefile = 'Testing_audio/spectre{}.wav'.format(snr)
    signal = pra.normalize(processed_audio_array[i], bits=16).astype(np.int16)
    wavfile.write(namefile,16000,signal)
    score_processing[i] = label_wav(namefile, labels_file, graph_file, 'no')
    
    namefile = 'Testing_audio/input{}.wav'.format(snr)
    signal = pra.normalize(noisy_save[i], bits=16).astype(np.int16)
    wavfile.write(namefile,16000,signal)
    score_original[i] = label_wav(namefile, labels_file, graph_file, 'no')
    
    namefile = 'Testing_audio/subspace{}.wav'.format(snr)
    signal = pra.normalize(processed_audio_subsapce[i], bits=16).astype(np.int16)
    wavfile.write(namefile,16000,signal)
    score_subspace[i] = label_wav(namefile, labels_file, graph_file, 'no')
    print()

# plotting the result
plt.figure()
plt.plot(snr_vals,score_processing, label="single noise channel removal signal")
plt.plot(snr_vals,score_original, label="original")
plt.plot(snr_vals,score_subspace, label="subspace")
plt.legend()
plt.title('SNR against percentage of confidence')
plt.xlabel('SNR in dB')
plt.ylabel('score')
plt.grid()
plt.show()